import { ParallaxProvider } from "react-scroll-parallax";
import ParallaxEffect from "./components/parallax/parallax";
import HomePage from "./home";

export default function App() {
  return (
    <>
    {/* <ParallaxProvider> */}
    <HomePage/> 
    {/* </ParallaxProvider> */}
    {/* <ParallaxEffect/> */}
    {/* <div className="font-saveya text-lg">
  This text uses the Saveya font.
</div>
<div className="font-editorial text-lg">
  This text uses the Editorial font.
</div> */}

    </>
  )
}