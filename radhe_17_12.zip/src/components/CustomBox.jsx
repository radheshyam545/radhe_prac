import React from 'react';

const CustomBox = () => {
  return (
    <div className="bg-[#152935] w-full h-[220px] flex items-center justify-center text-white">
    
    </div>
  );
};

export default CustomBox;
