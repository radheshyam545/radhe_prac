import main_logo from "../assets/logo/logo.png";
import second_banner from "../assets/second_banner.jpg";
import small_banner from "../assets/small_banner.jpg";
import third_banner from "../assets/third_banner.jpg";
import short_card_1 from "../assets/short_card_1.jpeg";
import bg_image from "../assets/bg_image.png";
import footer_logo from "../assets/footer_logo.png";
import small_card_2 from "../assets/small_card_2.jpg";

export {
    main_logo,
    second_banner,
    small_banner,
    third_banner,
    short_card_1,
    bg_image,
    footer_logo,
    small_card_2,
}